# seg(2-full) > 2023-11-20 2:59pm
https://universe.roboflow.com/bonefrac/seg-2-full

Provided by a Roboflow user
License: CC BY 4.0

